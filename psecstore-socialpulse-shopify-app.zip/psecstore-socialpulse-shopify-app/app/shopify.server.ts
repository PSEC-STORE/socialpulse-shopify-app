import "@shopify/shopify-app-react-router/adapters/node";
import { ApiVersion, AppDistribution, shopifyApp } from "@shopify/shopify-app-react-router/server";
import { PrismaSessionStorage } from "@shopify/shopify-app-session-storage-prisma";
import prisma from "./db.server";
import { syncMerchantRecord } from "./services/owner.server";

const shopify = shopifyApp({
  apiKey: process.env.SHOPIFY_API_KEY!,
  apiSecretKey: process.env.SHOPIFY_API_SECRET || "",
  apiVersion: ApiVersion.April26,
  scopes: process.env.SCOPES?.split(",") || [
    "read_products",
    "read_content",
    "read_inventory",
    "read_files",
  ],
  appUrl: process.env.SHOPIFY_APP_URL || "",
  authPathPrefix: "/auth",
  sessionStorage: new PrismaSessionStorage(prisma),
  distribution: AppDistribution.AppStore,
  hooks: {
    /**
     * Runs immediately after a merchant installs or re-authenticates the app.
     * Queries Shopify for the store owner's email and auto-grants FREE OWNER UNLIMITED ACCESS
     * if the email matches psecstore@gmail.com (Psecstore).
     */
    afterAuth: async ({ session, admin }) => {
      try {
        const res = await admin.graphql(`#graphql
          query GetShopOwnerInfo {
            shop {
              name
              email
              myshopifyDomain
            }
          }
        `);
        const json = await res.json();
        const shop = json.data?.shop;

        await syncMerchantRecord(prisma, {
          shopDomain: shop?.myshopifyDomain || session.shop,
          ownerEmail: shop?.email || session.email || "",
          shopName: shop?.name || session.shop,
        });
      } catch (err) {
        console.error("[afterAuth] Failed syncing merchant record:", err);
      }
    },
  },
});

export default shopify;
export const apiVersion = ApiVersion.April26;
export const addDocumentResponseHeaders = shopify.addDocumentResponseHeaders;
export const authenticate = shopify.authenticate;
export const unauthenticated = shopify.unauthenticated;
export const login = shopify.login;
export const registerWebhooks = shopify.registerWebhooks;
export const sessionStorage = shopify.sessionStorage;
